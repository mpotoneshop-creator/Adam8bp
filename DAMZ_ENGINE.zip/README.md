# DAMZ ENGINE — Android Studio project

A clean, standalone Android branding/UI project for DAMZ ENGINE. It does not include game injection,
memory hooks, automation, cheats, license bypasses, or anti-cheat evasion.

## Build APK automatically (no Android Studio needed)
1. Create a new GitHub repository.
2. Upload the contents of this ZIP to the repository (not the ZIP file itself).
3. Open the repository's **Actions** tab.
4. Select **Build DAMZ ENGINE APK** and tap **Run workflow** (or wait for the first push build).
5. Open the completed run, scroll to **Artifacts**, and download `DAMZ-ENGINE-APK`.
6. Extract the artifact ZIP; install `app-debug.apk` on Android.

## Build with Android Studio
Open this folder in Android Studio, allow Gradle sync, then choose Build > Build Bundle(s) / APK(s) > Build APK(s).

Application ID: `com.adamz.engine`
Minimum Android: 6.0 (API 23)
Target SDK: 34
