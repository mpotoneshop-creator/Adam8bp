package com.adamz.engine;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
    private final int BG = Color.rgb(8,8,8);
    private final int GOLD = Color.rgb(220,166,65);
    private final int MUTED = Color.rgb(166,166,166);

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(22), dp(22), dp(22), dp(28));
        page.setBackgroundColor(BG);
        scroll.addView(page);

        TextView brand = text("DAMZ ENGINE", 25, GOLD, true);
        brand.setLetterSpacing(.12f);
        page.addView(brand);

        TextView sub = text("ADAMZ  •  PERSONAL GAMING HUB", 11, MUTED, true);
        sub.setLetterSpacing(.12f);
        LinearLayout.LayoutParams sp = params(-2,-2); sp.topMargin=dp(5);
        page.addView(sub,sp);

        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.adamz_logo);
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        LinearLayout.LayoutParams lp = params(dp(218),dp(218));
        lp.gravity=Gravity.CENTER_HORIZONTAL; lp.topMargin=dp(24); lp.bottomMargin=dp(18);
        page.addView(logo,lp);

        LinearLayout status = card();
        TextView statusTitle = text("WELCOME BACK", 12, GOLD, true);
        statusTitle.setLetterSpacing(.12f);
        status.addView(statusTitle);
        TextView statusBody = text("DAMZ ENGINE siap digunakan sebagai pusat informasi dan personalisasi.", 14, Color.WHITE, false);
        LinearLayout.LayoutParams bp=params(-1,-2); bp.topMargin=dp(9);
        status.addView(statusBody,bp);
        page.addView(status,params(-1,-2));

        TextView heading = text("MENU UTAMA", 12, MUTED, true);
        heading.setLetterSpacing(.14f);
        LinearLayout.LayoutParams hp=params(-2,-2); hp.topMargin=dp(24); hp.bottomMargin=dp(10);
        page.addView(heading,hp);

        page.addView(menuCard("01", "PANDUAN", "Informasi penggunaan dan tips bermain yang fair."));
        page.addView(menuCard("02", "PENGATURAN", "Preferensi tampilan aplikasi DAMZ ENGINE."));
        page.addView(menuCard("03", "TENTANG APLIKASI", "Branding ADAMZ • Versi 1.0"));

        TextView footer=text("MADE BY ADAMZ",10,MUTED,true);
        footer.setGravity(Gravity.CENTER);
        footer.setLetterSpacing(.2f);
        LinearLayout.LayoutParams fp=params(-1,-2); fp.topMargin=dp(26);
        page.addView(footer,fp);
        setContentView(scroll);
    }

    private View menuCard(String n, String title, String desc) {
        LinearLayout c=card();
        c.setOrientation(LinearLayout.HORIZONTAL);
        TextView number=text(n,13,GOLD,true);
        number.setGravity(Gravity.CENTER);
        GradientDrawable badge=new GradientDrawable();
        badge.setColor(Color.rgb(42,25,17)); badge.setCornerRadius(dp(12));
        number.setBackground(badge);
        c.addView(number,params(dp(42),dp(42)));
        LinearLayout col=new LinearLayout(this); col.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams cp=params(0,-2,1); cp.leftMargin=dp(14);
        col.addView(text(title,14,Color.WHITE,true));
        TextView d=text(desc,12,MUTED,false);
        LinearLayout.LayoutParams descParams=params(-1,-2); descParams.topMargin=dp(5);
        col.addView(d,descParams);
        c.addView(col,cp);
        LinearLayout.LayoutParams outer=params(-1,-2); outer.topMargin=dp(9);
        c.setOnClickListener(v -> Toast.makeText(this,title,Toast.LENGTH_SHORT).show());
        c.setFocusable(true);
        c.setClickable(true);
        c.setElevation(dp(1));
        c.setTag(n);
        c.setPadding(dp(15),dp(14),dp(15),dp(14));
        return c;
    }

    private LinearLayout card() {
        LinearLayout c=new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(17),dp(16),dp(17),dp(16));
        GradientDrawable bg=new GradientDrawable();
        bg.setColor(Color.rgb(20,20,20));
        bg.setCornerRadius(dp(16));
        bg.setStroke(dp(1),Color.rgb(67,48,27));
        c.setBackground(bg);
        return c;
    }
    private TextView text(String s,int size,int color,boolean bold) {
        TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        t.setTypeface(Typeface.create("sans-serif",bold?Typeface.BOLD:Typeface.NORMAL));
        return t;
    }
    private LinearLayout.LayoutParams params(int w,int h) { return new LinearLayout.LayoutParams(w,h); }
    private LinearLayout.LayoutParams params(int w,int h,float weight) { return new LinearLayout.LayoutParams(w,h,weight); }
    private int dp(int v) { return (int)(v*getResources().getDisplayMetrics().density+.5f); }
}
